"use server"

import { redirect } from "next/navigation"
import { validateCredentials, createSession, destroySession } from "@/lib/auth"

export async function loginAction(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const rememberMe = formData.get("rememberMe") === "on"

  // Validate input
  if (!email || !password) {
    return {
      error: "Email and password are required",
    }
  }

  if (!/\S+@\S+\.\S+/.test(email)) {
    return {
      error: "Please enter a valid email address",
    }
  }

  if (password.length < 6) {
    return {
      error: "Password must be at least 6 characters",
    }
  }

  try {
    // Validate credentials
    const user = await validateCredentials(email, password)

    if (!user) {
      return {
        error: "Invalid email or password",
      }
    }

    // Create session
    await createSession(user)

    // Log successful login (in production, use proper logging)
    console.log(`User ${user.email} logged in successfully`)
  } catch (error) {
    console.error("Login error:", error)
    return {
      error: "An error occurred during login. Please try again.",
    }
  }

  // Redirect to dashboard
  redirect("/dashboard")
}

export async function logoutAction() {
  await destroySession()
  redirect("/login")
}
