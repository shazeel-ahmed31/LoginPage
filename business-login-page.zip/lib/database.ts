// Example database integration with Supabase
// Uncomment and configure when ready to use a real database

/*
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)

export async function validateCredentialsDB(email: string, password: string) {
  const { data: user, error } = await supabase
    .from('users')
    .select('id, email, name, role, company')
    .eq('email', email)
    .eq('password', password) // In production, use proper password hashing
    .single()

  if (error || !user) {
    return null
  }

  return user
}

export async function createUser(userData: {
  email: string
  password: string
  name: string
  role: string
  company: string
}) {
  const { data, error } = await supabase
    .from('users')
    .insert([userData])
    .select()
    .single()

  if (error) {
    throw new Error(error.message)
  }

  return data
}
*/

// SQL schema for users table:
/*
CREATE TABLE users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL, -- Use bcrypt in production
  name VARCHAR(255) NOT NULL,
  role VARCHAR(100) NOT NULL,
  company VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
*/
