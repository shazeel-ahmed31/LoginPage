import { cookies } from "next/headers"
import { redirect } from "next/navigation"

// Simple user database (in production, use a real database)
const users = [
  {
    id: "1",
    email: "demo@business.com",
    password: "password123", // In production, use hashed passwords
    name: "John Doe",
    role: "Admin",
    company: "BusinessPro Inc.",
  },
  {
    id: "2",
    email: "user@business.com",
    password: "userpass123",
    name: "Jane Smith",
    role: "User",
    company: "BusinessPro Inc.",
  },
]

export interface User {
  id: string
  email: string
  name: string
  role: string
  company: string
}

export async function validateCredentials(email: string, password: string): Promise<User | null> {
  // Simulate database lookup with delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const user = users.find((u) => u.email === email && u.password === password)
  if (user) {
    const { password: _, ...userWithoutPassword } = user
    return userWithoutPassword
  }
  return null
}

export async function createSession(user: User) {
  const cookieStore = await cookies()

  // In production, use proper JWT tokens or session tokens
  const sessionData = {
    userId: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    company: user.company,
    expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
  }

  cookieStore.set("session", JSON.stringify(sessionData), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 24 * 60 * 60, // 24 hours
  })
}

export async function getSession(): Promise<User | null> {
  try {
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get("session")

    if (!sessionCookie) return null

    const sessionData = JSON.parse(sessionCookie.value)

    // Check if session is expired
    if (Date.now() > sessionData.expiresAt) {
      await destroySession()
      return null
    }

    return {
      id: sessionData.userId,
      email: sessionData.email,
      name: sessionData.name,
      role: sessionData.role,
      company: sessionData.company,
    }
  } catch {
    return null
  }
}

export async function destroySession() {
  const cookieStore = await cookies()
  cookieStore.delete("session")
}

export async function requireAuth(): Promise<User> {
  const user = await getSession()
  if (!user) {
    redirect("/login")
  }
  return user
}
