import Component from "../business-login"

export default function Page() {
  return <Component />
}
